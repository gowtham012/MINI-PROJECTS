<br>
<br>
<br>
<br>
<center><font color="ivory"><b><i>Declaration: </i></b></font><font color="olive"><i>YOUR VOTE IS YOUR BUTT&nbsp;</i></center></font>
</body>
</html>
