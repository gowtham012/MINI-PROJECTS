<?php 
$con = mysqli_connect("localhost","root","","polltest") or die ("error" . mysqli_error($con));
?>
