package student;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class adminlogin extends JFrame {

	private JPanel contentPane;
	private JTextField adminusername;
	private JTextField adminpassword;
	public static adminlogin frame;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new adminlogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public adminlogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 519, 554);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		adminusername = new JTextField();
		adminusername.setBounds(178, 121, 186, 43);
		contentPane.add(adminusername);
		adminusername.setColumns(10);
		
		adminpassword = new JTextField();
		adminpassword.setColumns(10);
		adminpassword.setBounds(173, 233, 191, 43);
		contentPane.add(adminpassword);
		
		JLabel lblNewLabel = new JLabel("Admin Login");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel.setBounds(196, 20, 117, 70);
		contentPane.add(lblNewLabel);
		
		JButton btnAdminLogin = new JButton("Admin Login");
		btnAdminLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				String name1=adminusername.getText();
				String password1=adminusername.getText();
			
				if(name1.equals("admin") && password1.equals("admin123"))
				{
					adminList.main(null);
					frame.dispose();
					
				}else{
					JOptionPane.showMessageDialog(adminlogin.this,"Sorry, username or password error!","Login error!",JOptionPane.ERROR_MESSAGE);
					
					
				}
				}
			
		});
		btnAdminLogin.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		btnAdminLogin.setBounds(209, 344, 126, 43);
		contentPane.add(btnAdminLogin);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblUsername.setBounds(63, 127, 79, 37);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblPassword.setBounds(63, 250, 79, 37);
		contentPane.add(lblPassword);
	}
}
