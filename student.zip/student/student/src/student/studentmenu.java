package student;


import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

public class studentmenu extends JFrame
{private studentmenu frame;
		public JLabel stname;
	private JPanel contentPane;
	public JTable table;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					studentmenu frame = new studentmenu();
					frame.setVisible(true);
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public studentmenu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 576, 382);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnAddNew = new JButton("Add New");
		btnAddNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{		studentmenu frame =new studentmenu();
				try {String m=stname.getText();
				Class.forName("com.mysql.jdbc.Driver");
				Connection con= DriverManager.getConnection("jdbc:mysql://localhost/student_empowerment","root","");
				PreparedStatement ps=con.prepareStatement("select * from student_list WHERE name = ?");
				ps.setString(1,m);
				ResultSet rs=ps.executeQuery();
				boolean validate =rs.next();
				if(validate)
				{
					JOptionPane.showMessageDialog(studentmenu.this,"Sorry, You Have Alreay created a list!","Cant ADD!",JOptionPane.ERROR_MESSAGE);
					
					
				}else
				{
					
					String nam=stname.getText();
					addStudentList ms =new addStudentList();
					ms.nname.setText(nam);
					ms.setVisible(true);
					frame.dispose();
			
				}
			} catch (ClassNotFoundException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}
		});
		btnAddNew.setBounds(41, 74, 112, 40);
		contentPane.add(btnAddNew);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				try {String m=stname.getText();
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost/student_empowerment","root","");
					PreparedStatement ps=con.prepareStatement(" DELETE FROM `student_list` WHERE name = ?");
					ps.setString(1, m);
					int status=ps.executeUpdate();
					
					
				} catch (ClassNotFoundException | SQLException e1)
				{
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
		btnDelete.setBounds(395, 74, 112, 40);
		contentPane.add(btnDelete);
		
		JButton btnModify = new JButton("Modify");
		btnModify.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{studentmenu frame =new studentmenu();
				String x=stname.getText();
				studentUpdatedetails s= new studentUpdatedetails();
			s.usname.setText(x);
				s.setVisible(true);
				frame.dispose();
			}
		});
		btnModify.setBounds(224, 119, 112, 40);
		contentPane.add(btnModify);
		
		JButton btnView = new JButton("View");
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				try {
					String s=stname.getText();
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost/student_empowerment","root","");
					PreparedStatement ps=con.prepareStatement("select * from student_list WHERE name = ?");
					ps.setString(1,s);
					ResultSet rs= ps.executeQuery();
				
					table.setModel(DbUtils.resultSetToTableModel(rs));
				
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					
					e.printStackTrace();
				}
			
			}
		});
		btnView.setBounds(224, 205, 112, 40);
		contentPane.add(btnView);
		
		JLabel lblStudentDesktop = new JLabel("Student Desktop");
		lblStudentDesktop.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblStudentDesktop.setBounds(216, 10, 174, 60);
		contentPane.add(lblStudentDesktop);
		
		 stname = new JLabel("name");
		stname.setBounds(259, 88, 45, 13);
		contentPane.add(stname);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(41, 258, 466, 87);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
	}

}
