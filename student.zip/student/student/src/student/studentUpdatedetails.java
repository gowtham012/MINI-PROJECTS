package student;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;

public class studentUpdatedetails extends JFrame {

	private JPanel contentPane;
	private JTextField eddress;
	private JTextField edpen;
	private JTextField edbook;
	private JTextField edbag;
	public static studentUpdatedetails frame;
	public JLabel usname;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new studentUpdatedetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public studentUpdatedetails() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 591, 670);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		eddress = new JTextField();
		eddress.setBounds(196, 96, 137, 34);
		contentPane.add(eddress);
		eddress.setColumns(10);
		
		JButton btnNewButton = new JButton("Chang details");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				try {
					
					Class.forName("com.mysql.jdbc.Driver");

					Connection con= DriverManager.getConnection("jdbc:mysql://localhost/student_empowerment","root","");
					String name=usname.getText();
					String dress=eddress.getText();
					String book=edbook.getText();
					String bag=edbag.getText();
					String pen=edpen.getText();
					
					PreparedStatement ps=con.prepareStatement("UPDATE `student_list` SET `dress`='\"+eddress.getText();+\"',`book`='\"+edbook.getText();+\"',`bag`='\"+edbag.getText();+\"',`pen`='\"+edpen.getText();+\"' WHERE name='\"+usname.getText();+\"'");
					
					int status=ps.executeUpdate();
					
					studentmenu sm= new studentmenu();
					sm.stname.setText(name);
					sm.setVisible(true);
					
					
				} catch (ClassNotFoundException | SQLException e1)
				{
					// TODO Auto-generated catch block
					e1.printStackTrace();
				};
				
				
			}
		});
		btnNewButton.setBounds(196, 499, 131, 34);
		contentPane.add(btnNewButton);
		
		edpen = new JTextField();
		edpen.setColumns(10);
		edpen.setBounds(196, 180, 137, 34);
		contentPane.add(edpen);
		
		edbook = new JTextField();
		edbook.setColumns(10);
		edbook.setBounds(196, 268, 137, 34);
		contentPane.add(edbook);
		
		edbag = new JTextField();
		edbag.setColumns(10);
		edbag.setBounds(196, 375, 137, 34);
		contentPane.add(edbag);
		
		JLabel lblEditDetails = new JLabel("EditList");
		lblEditDetails.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblEditDetails.setBounds(211, 24, 105, 39);
		contentPane.add(lblEditDetails);
		
		JLabel lblNewLabel = new JLabel("Uniform");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(74, 98, 77, 24);
		contentPane.add(lblNewLabel);
		
		JLabel lblPenpenceils = new JLabel("Pen/Penceils");
		lblPenpenceils.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPenpenceils.setBounds(74, 182, 92, 24);
		contentPane.add(lblPenpenceils);
		
		JLabel lblBooks = new JLabel("Books");
		lblBooks.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBooks.setBounds(74, 278, 92, 24);
		contentPane.add(lblBooks);
		
		JLabel lblSchoolBags = new JLabel("School Bags");
		lblSchoolBags.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblSchoolBags.setBounds(74, 385, 92, 24);
		contentPane.add(lblSchoolBags);
		
		usname = new JLabel("name");
		usname.setFont(new Font("Tahoma", Font.PLAIN, 15));
		usname.setBounds(415, 40, 105, 23);
		contentPane.add(usname);
	}
}
