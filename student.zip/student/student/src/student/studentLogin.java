package student;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Frame;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class studentLogin extends JFrame{
	static studentLogin frame1;
	private JPanel contentPane;
	private JTextField logusername;
	private JTextField logpassword;
	private JButton btnNewButton;
	private JLabel lblDontHaveAccount;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame1= new studentLogin();
					frame1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public studentLogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		logusername = new JTextField();
		logusername.setBounds(89, 65, 156, 39);
		contentPane.add(logusername);
		logusername.setColumns(10);
		
		logpassword = new JTextField();
		logpassword.setBounds(89, 132, 156, 39);
		contentPane.add(logpassword);
		logpassword.setColumns(10);
		
		JLabel lblStudentLogin = new JLabel("Student Login");
		lblStudentLogin.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblStudentLogin.setBounds(103, 10, 114, 33);
		contentPane.add(lblStudentLogin);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost/student_empowerment","root","");
					String name=logusername.getText();
					String password=logpassword.getText();
					
					PreparedStatement ps=con.prepareStatement("select * from students where name=? and password=?");
					ps.setString(1,name);
					ps.setString(2,password);
					ResultSet rs=ps.executeQuery();
					boolean validate =rs.next();
					if(validate)
					{
						studentmenu sts =new studentmenu();
						sts.stname.setText(name);
						sts.setVisible(true);
						
						
							frame1.dispose();
							con.close();
				
					}else
					{
						JOptionPane.showMessageDialog(studentLogin.this,"Sorry, username or password error!","Login error!",JOptionPane.ERROR_MESSAGE);
					}
				} catch (ClassNotFoundException | SQLException e1) 
				
				{
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnLogin.setBounds(103, 192, 107, 39);
		contentPane.add(btnLogin);
		
		btnNewButton = new JButton("Register");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				addNewStudent.main(null);
				frame1.dispose();
				
			}
		});
		btnNewButton.setBounds(311, 111, 107, 39);
		contentPane.add(btnNewButton);
		
		lblDontHaveAccount = new JLabel("Dont have Account");
		lblDontHaveAccount.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblDontHaveAccount.setBounds(311, 64, 114, 39);
		contentPane.add(lblDontHaveAccount);
	}

}
