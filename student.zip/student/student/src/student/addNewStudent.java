package student;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class addNewStudent extends JFrame {
static addNewStudent frame;
	private JPanel contentPane;
	private JTextField adname;
	private JTextField adusn;
	private JTextField adphone;
	private JTextField adpassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new addNewStudent();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public addNewStudent() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 605, 653);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		adname = new JTextField();
		adname.setBounds(198, 101, 202, 48);
		contentPane.add(adname);
		adname.setColumns(10);
		
		adusn = new JTextField();
		adusn.setColumns(10);
		adusn.setBounds(198, 199, 202, 48);
		contentPane.add(adusn);
		
		adphone = new JTextField();
		adphone.setColumns(10);
		adphone.setBounds(198, 308, 202, 48);
		contentPane.add(adphone);
		
		adpassword = new JTextField();
		adpassword.setColumns(10);
		adpassword.setBounds(198, 414, 202, 48);
		contentPane.add(adpassword);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblName.setBounds(82, 107, 63, 31);
		contentPane.add(lblName);
		
		JLabel lUsn = new JLabel("USN");
		lUsn.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lUsn.setBounds(82, 216, 63, 31);
		contentPane.add(lUsn);
		
		JLabel lblPhone = new JLabel("Phone");
		lblPhone.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblPhone.setBounds(82, 325, 63, 31);
		contentPane.add(lblPhone);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblPassword.setBounds(67, 431, 78, 31);
		contentPane.add(lblPassword);
		
		JLabel lblNewLabel = new JLabel("Student Register");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel.setBounds(198, 23, 154, 48);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				String name=adname.getText();
				String usn=adusn.getText();
				String password=adpassword.getText();
				String phone=adphone.getText();
				int status=0;
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost/student_empowerment","root","");
					
					PreparedStatement ps=con.prepareStatement("insert into students(name,usn,phone,password) values(?,?,?,?)");
					ps.setString(1,name);
					ps.setString(2,usn);
					ps.setString(3,phone);
					ps.setString(4,password);
					status=ps.executeUpdate();
				
					if(status!=0)
					{
						studentLogin.main(new String[]{});
							frame.dispose();
							con.close();
				
					}else
					{
						JOptionPane.showMessageDialog(addNewStudent.this,"Sorry, username or password error!","Login error!",JOptionPane.ERROR_MESSAGE);
					}
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
	
			}

		});
		btnNewButton.setBounds(243, 518, 108, 48);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setBounds(430, 545, 85, 21);
		contentPane.add(btnNewButton_1);
	}

}
