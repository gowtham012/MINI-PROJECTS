package student;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class studentall 
{
	private String name,dress,pen,book,bag;
	public static Connection getCon()
	{
		Connection con=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/test","root","");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	
	public void all(String name,String dress,String pen,String book,String bag)
	{
		getCon();
		this.name=name;
		this.dress=dress;
		this.pen=pen;
		this.book=book;
		this.bag=bag;
		
	}
		
		
		
		}
	

