package student;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class addStudentList extends JFrame {
	
	private JPanel contentPane;
	private JTextField aduniform;
	private JTextField adpen;
	private JTextField adbook;
	private JTextField adbag;
	public	JLabel nname;
	private  addStudentList frame;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				addStudentList frame3 = new addStudentList();
					frame3.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public addStudentList() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 773, 476);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		aduniform = new JTextField();
		aduniform.setBounds(209, 70, 132, 33);
		contentPane.add(aduniform);
		aduniform.setColumns(10);
		
		JLabel lblUniform = new JLabel("Uniform");
		lblUniform.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblUniform.setBounds(75, 80, 57, 23);
		contentPane.add(lblUniform);
		
		JLabel lblPenpenceils = new JLabel("Pen/Penceils");
		lblPenpenceils.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPenpenceils.setBounds(75, 145, 99, 23);
		contentPane.add(lblPenpenceils);
		
		JLabel lblBooks = new JLabel("Books");
		lblBooks.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBooks.setBounds(75, 206, 99, 23);
		contentPane.add(lblBooks);
		
		JLabel lblSchoolBags = new JLabel("School Bags");
		lblSchoolBags.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblSchoolBags.setBounds(75, 277, 99, 23);
		contentPane.add(lblSchoolBags);
		
		adpen = new JTextField();
		adpen.setColumns(10);
		adpen.setBounds(209, 142, 132, 33);
		contentPane.add(adpen);
		
		adbook = new JTextField();
		adbook.setColumns(10);
		adbook.setBounds(209, 203, 132, 33);
		contentPane.add(adbook);
		
		adbag = new JTextField();
		adbag.setColumns(10);
		adbag.setBounds(209, 274, 132, 33);
		contentPane.add(adbag);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost/student_empowerment","root","");
					String name=nname.getText();
					String deress=aduniform.getText();
					String book=adbook.getText();
					String bag=adbag.getText();
					String pen=adpen.getText();
					
					PreparedStatement ps=con.prepareStatement("insert into student_list(name,dress,book,bag,pen) values(?,?,?,?,?)");
					ps.setString(1,name);
					ps.setString(2,deress);
					ps.setString(3, book);
					ps.setString(4,bag);
					ps.setString(5,pen);
					int status=ps.executeUpdate();
					
					if(status!=0)
					{addStudentList frame =new addStudentList();
						studentmenu st =new studentmenu();
						st.stname.setText(name);
						st.setVisible(true);
						frame.setVisible(false);
				
						
				
					}
					else
					{
						
					}
					
				} catch (ClassNotFoundException | SQLException e1) 
				{
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
		btnSubmit.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnSubmit.setBounds(534, 185, 140, 44);
		contentPane.add(btnSubmit);
		
		nname = new JLabel("name");
		nname.setFont(new Font("Tahoma", Font.PLAIN, 14));
		nname.setBounds(313, 10, 113, 54);
		contentPane.add(nname);
	}

}
